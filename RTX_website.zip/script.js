
console.log('مرحبا بك في موقع RTX');
